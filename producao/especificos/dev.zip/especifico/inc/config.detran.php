<?php

//Dados do detran
$config['detran'] = [
    'SE' => [
        'urlSoap' => 'http://172.28.64.58:8089/wsIntegracaoEAD',
        'urlWsl' => 'http://172.28.64.58:8089/wsIntegracaoEAD?WSDL',
        'pUsuario' => 'DET53001',
        'pSenha' => 'DET53001',
        'pAmbiente' => 'D',//D = Desenvolvimento, P = Produção
        'registro_instrutor' => '02179568548',//Registro da CNH
    ],
    'PE' => [
        'urlJSON' => 'http://200.238.67.2:51175/JsonEAD.svc',
        'registro_empresa' => '02968119000188',//Registro da CNPJ
        'registro_instrutor' => '56555040653',//Registro do CPF
    ],
    'RS' => [
        'urlJSON' => 'https://mgfc.detran.rs.gov.br/gfc/rest/gfcmobile/cursoEAD',
        'organizacao' => 'SISTEMA',
        'matricula' => '4436',
        'senha' => '57ir5005',
        'codEmpresa' => 'EAD00009',
        'registro_instrutor' => '56555040653',
    ],
    'PR' => [
        //'urlJSON' => 'http://homolog.wsutils.detran.pr.gov.br/detran-wsutils',
        'urlJSON' => 'http://www.wsutils.detran.pr.gov.br/detran-wsutils',
        'id' => 311720, //para autenticação
        'chave' => '61fdc276f892f9240dbf904e797a4c1a', //para autenticação
        'registro_instrutor' => '49028715991',
        'registro_empresa' => '08146138000105',//Registro da CNPJ
    ],
    'RJ' => [
        // 'urlWsl' => 'http://charon:8080/wsstack/services/ENSINODI.wsdl', // DESENVOLVIMENTO
        'urlWsl' => 'http://leao:8080/wsstack/services/ENSINODI.wsdl', // PRODUÇÃO
        'pUsuario' => 'COENSIBR',
        // 'pSenha' => 'COENS123',  // DESENVOLVIMENTO
        'pSenha' => 'IBREP201',  // PRODUÇÃO
        'registro_empresa' => '08146138000105',//Registro da CNPJ
        'registro_instrutor' => '49028715991',//Registro da CNH
        'caer' => 'RJ52039',
    ],
    'MA' => [
        'urlWsl' => 'http://wsprodwebapp.detran.ma.gov.br:10010/wsstack/services/wsRegistroCursoEAD?wsdl', // PRODUÇÃO
        'usuario' => 'IBREP',
        'senha' => 'DT1@5Y82RE',  // PRODUÇÃO
        'cnpj_entidade' => '08146138000105',//Registro da CNPJ
        'cpf_instrutor' => '49028715991',//Registro da CNH
    ],
    'ES' => [
        'urlWsl' => 'https://renach2.es.gov.br/WebServices/EAD/wsEAD.asmx?WSDL',
        'login' => 'IBREP',
        'cpf_instrutor' => '49028715991',
        'chave' => '}Ghx-#5$EoA;yx9QkCw[U5b|1BPq=TZd'
    ],
    'MS' => [
        'urlLiberacao' => 'http://www2.detran.ms.gov.br/detranet/ead/consCond/consCond.asp',
        'urlConclusao' => 'http://www2.detran.ms.gov.br/detranet/ead/regCond/regCond.asp',
        'cnpjInst' => '08146138000105',
        'ip' => '177.47.183.17'
    ],
    'MT' => [
        'urlWsl' => 'http://ws.detrannet.mt.gov.br:8080/wsEventoCurso/wsEventoCurso.asmx?wsdl',
        'integrador' => 'ICET2',
        'chave' => '46c7ac3b12a323fd3dab',
        'cpf_instrutor' => '56555040653',
        'cnpj_entidade' => '02968119000188',
    ],
    'AL' => [
        // 'urlWslLiberacao' => 'https://wshml01.detran.al.gov.br/wsstack/services/CFCNW020?wsdl', // DESENVOLVIMENTO
        // 'urlWslConclusao' => 'https://wshml01.detran.al.gov.br/wsstack/services/CFCNW045?wsdl', // DESENVOLVIMENTO
        'urlWslLiberacao' => 'https://wsprd02.detran.al.gov.br/wsstack/services/CFCNW020?wsdl', // PRODUÇÃO
        'urlWslConclusao' => 'https://wsprd02.detran.al.gov.br/wsstack/services/CFCNW045?wsdl', // PRODUÇÃO
        'matricula' => '95750',
        'cpf_instrutor' => '49028715991',
        'cnpjInst' => '08146138000105',
    ],
    'SC' => [
        'urlJSON' => 'https://dev.apim.ciasc.sc.gov.br:8243/credenciamento-api/v1', // DESENVOLVIMENTO
//        'urlJSON' => 'https://apim.ciasc.sc.gov.br:8243/credenciamento-api', // PRODUÇÃO
        'cpf_instrutor' => '01735602965',
        'cnpjInst' => '73471963016060',
        'token' => 'eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsIng1dCI6Ik5UZG1aak00WkRrM05qWTBZemM1TW1abU9EZ3dNVEUzTVdZd05ERTVNV1JsWkRnNE56YzRaQT09In0.eyJhdWQiOiJodHRwOlwvXC9vcmcud3NvMi5hcGltZ3RcL2dhdGV3YXkiLCJzdWIiOiJhZG1pbkBjYXJib24uc3VwZXIiLCJhcHBsaWNhdGlvbiI6eyJvd25lciI6ImFkbWluIiwidGllclF1b3RhVHlwZSI6InJlcXVlc3RDb3VudCIsInRpZXIiOiJVbmxpbWl0ZWQiLCJuYW1lIjoiQXBwLUNyZWRlbmNpYW1lbnRvIiwiaWQiOjY1LCJ1dWlkIjpudWxsfSwic2NvcGUiOiJhbV9hcHBsaWNhdGlvbl9zY29wZSBkZWZhdWx0IiwiaXNzIjoiaHR0cHM6XC9cL2Rldi5hY2Vzc28uY2lhc2Muc2MuZ292LmJyOjQ0M1wvb2F1dGgyXC90b2tlbiIsInRpZXJJbmZvIjp7IlVubGltaXRlZCI6eyJ0aWVyUXVvdGFUeXBlIjoicmVxdWVzdENvdW50Iiwic3RvcE9uUXVvdGFSZWFjaCI6dHJ1ZSwic3Bpa2VBcnJlc3RMaW1pdCI6MCwic3Bpa2VBcnJlc3RVbml0IjpudWxsfX0sImtleXR5cGUiOiJQUk9EVUNUSU9OIiwic3Vic2NyaWJlZEFQSXMiOlt7InN1YnNjcmliZXJUZW5hbnREb21haW4iOiJjYXJib24uc3VwZXIiLCJuYW1lIjoiQ3JlZGVuY2lhbWVudG9BUEkiLCJjb250ZXh0IjoiXC9jcmVkZW5jaWFtZW50by1hcGlcL3YxIiwicHVibGlzaGVyIjoiYWRtaW4iLCJ2ZXJzaW9uIjoidjEiLCJzdWJzY3JpcHRpb25UaWVyIjoiVW5saW1pdGVkIn1dLCJjb25zdW1lcktleSI6ImJKWnVrZGpZTjVrUjZtRFBxczI5R3NaZnVnUWEiLCJleHAiOjM3Nzk4MjcwMTcsImlhdCI6MTYzMjM0MzM3MCwianRpIjoiZTNhZWI0YWQtNGRhZS00ODA5LTljYWItNjdjNzVmMWE5NzM3In0.XzO-2xsLTZW0cYNh15GVZ2e5DeXTWU7TgfeyiMvYnlP_k_21LoXWWB9t00NFKZcHSss_SW7IDaXC1_UHuwFb0wt7AkLdyL4l9ZbRVLiH4Vea2akXJXmbF3LaxMELOCVvrMmmoO0NwFp8OxShxKJFlorIkhTUxkRs9B-ETDdXMVoTE0qARFLXjp0UFEkmlhDiGBc2u84bGEgyH7-CKj3m1M836QnWuP5tigeUEG_MG5qgW4-lN_4NJNGkJ2UmjDEkMNMmIbhWG9WQZ8KF-UCsuK_LAtObeRKMarE8NFPVojHOTWLSrLfGUXzng-o70Tk0zEMX0hVd9bRdP9r0FWOUSA'
    ],
    'CE' => [
        'urlJSON' => 'https://dtirchservice.detran.ce.gov.br/integradorcfc/cursosEad',
        'chaveAcesso' => '7ff2576002083e5647f7f2293547b6f87960d8c0'
        //'chaveAcesso' => 'a39a3ee5e6b4b0d3255bfef95601890afd80709'
    ],
];
//Estados integrados com o Detran
$estadosDetran = [
    'AL' => 2,
    'CE' => 6,
    'ES' => 8,
    'MA' => 10,
    'MS' => 12,
    'MT' => 11,
    'PE' => 17,
    'PR' => 16,
    'RJ' => 19,
    'RS' => 21,
    'SE' => 26
];

//Código dos cursos de motociclista no detran
$detran_tipo_aula_motociclista = [
    'PE' => [
        12 => ['codigo' => 55, 'modulo' => 2], // MOTOFRETISTA
    ]
];

//Código dos cursos no detran
$detran_tipo_aula = [
    
    'SE' => [
        3 => [
            'CODIGO' => 'R',
            'DISCIPLINAS' =>
                [
                    7 => 'L',//Legislação de Trânsito
                    8 => 'D',//Direção Defensiva
                    9 => 'S',//Noções de Primeiros Socorros
                    10 => 'R'//Relacionamento Interpessoal
                ]
        ], //RECICLAGEM DE CONDUTORES INFRATORES
        5 => [
            'CODIGO' => 'A',
            'DISCIPLINAS' =>
                [
                    7 => 'L',//Legislação de Trânsito
                    8 => 'D',//Direção Defensiva
                    9 => 'S',//Noções de Primeiros Socorros
                    10 => 'R'//Relacionamento Interpessoal
                ]
        ],//ATUALIZAÇÃO PARA RENOVAÇÃO DA CNH
        12 => [
            'CODIGO' => 'R',
            'DISCIPLINAS' =>
                [
                    7 => 'L',//Legislação de Trânsito
                    8 => 'D',//Direção Defensiva
                    9 => 'S',//Noções de Primeiros Socorros
                    10 => 'R'//Relacionamento Interpessoal
                ]
        ], //RECICLAGEM DE CONDUTORES INFRATORES
    ],
    'PE' => [
        12 => ['codigo' => 55, 'modulo' => 1],   // MOTOFRETISTA
        3 => ['codigo' => 55, 'modulo' => 1],   // teste
    ],
    'RS' => [
        /*
        51 => 51, // MOTOTAXISTA SEMIPRESENCIAL
        50 => 50, // MOTOFRETISTA SEMIPRESENCIAL
        49 => 49, // PREVENTIVO DE RECICLAGEM EAD*/
        29 => 18, // ATUALIZAÇÃO PARA MOTOTAXISTA SEMIPRESENCIAL
        28 => 18, // ATUALIZAÇÃO PARA MOTOFRETISTA SEMIPRESENCIAL
        22 => 18, // ATUALIZAÇÃO PARA RENOVAÇÃO DA CNH EAD
        20 => 10, // RECICLAGEM PARA CONDUTORES INFRATORES EAD
        18 => 18, // ATUALIZAÇÃO PARA CONDUTORES DE VEÍCULO DE TRANSPORTE DE CARGA INDIVISÍVEL EAD
        17 => 18, // ATUALIZAÇÃO PARA CONDUTORES DE VEÍCULO DE EMERGÊNCIA EAD
        16 => 18, // ATUALIZAÇÃO PARA CONDUTORES DE VEÍCULO DE TRANSPORTE DE PRODUTOS PERIGOSOS EAD
        15 => 18, // ATUALIZAÇÃO PARA CONDUTORES VEÍCULO DE TRANSPORTE DE ESCOLARES EAD
        14 => 18, // ATUALIZAÇÃO PARA CONDUTORES DE VEÍCULO DE TRANSPORTE COLETIVO DE PASSAGEIROS EAD
        12 => 18, // ATUALIZAÇÃO PARA CONDUTORES DE VEÍCULO DE TRANSPORTE COLETIVO DE PASSAGEIROS EAD
        /*13 => 13, // CONDUTORES DE VEÍCULOS DE TRANSPORTE DE CARGA INDIVISÍVEL EAD
        12 => 12, // CONDUTORES DE VEÍCULOS DE EMERGÊNCIA EAD
        11 => 11, // CONDUTORES DE VEÍCULOS DE TRANSPORTE DE PRODUTOS PERIGOSOS EAD
        10 => 10, // CONDUTORES DE VEÍCULOS DE TRANSPORTE DE ESCOLARES EAD
        9 => 9,   // CONDUTORES DE VEÍCULO DE TRANSPORTE COLETIVO DE PASSAGEIROS EAD*/
    ],
    'PR' => [
        4 => 10, //RECICLAGEM DE CONDUTORES INFRATORES
        6 => 10, //RECICLAGEM DE CONDUTORES INFRATORES 2.0,
        7 => 10,
        12 => 10,
    ],
    'RJ' => [
        4 =>  20,//RECICLAGEM DE CONDUTORES INFRATORES
        12 =>  20//RECICLAGEM DE CONDUTORES INFRATORES
    ],
    'MA' => [
        4 => 20, //RECICLAGEM DE CONDUTORES INFRATORES
        12 => 20 //RECICLAGEM DE CONDUTORES INFRATORES
    ],
    'ES' => [
        6 => 20, //RECICLAGEM DE CONDUTORES INFRATORES 2.0
        12 => 20 //RECICLAGEM DE CONDUTORES INFRATORES 2.0
    ],
    'MS' => [
        4 => 'R', //RECICLAGEM DE CONDUTORES INFRATORES
        12 => 'R' //RECICLAGEM DE CONDUTORES INFRATORES
    ],
    'MT' => [
        /*
        51 => 51, // MOTOTAXISTA SEMIPRESENCIAL
        50 => 50, // MOTOFRETISTA SEMIPRESENCIAL
        49 => 49, // PREVENTIVO DE RECICLAGEM EAD*/
        29 => 30, // ATUALIZAÇÃO PARA MOTOTAXISTA SEMIPRESENCIAL
        28 => 30, // ATUALIZAÇÃO PARA MOTOFRETISTA SEMIPRESENCIAL
        22 => 30, // ATUALIZAÇÃO PARA RENOVAÇÃO DA CNH EAD
        20 => 20, // RECICLAGEM PARA CONDUTORES INFRATORES EAD
        18 => 30, // ATUALIZAÇÃO PARA CONDUTORES DE VEÍCULO DE TRANSPORTE DE CARGA INDIVISÍVEL EAD
        17 => 30, // ATUALIZAÇÃO PARA CONDUTORES DE VEÍCULO DE EMERGÊNCIA EAD
        16 => 30, // ATUALIZAÇÃO PARA CONDUTORES DE VEÍCULO DE TRANSPORTE DE PRODUTOS PERIGOSOS EAD
        15 => 30, // ATUALIZAÇÃO PARA CONDUTORES VEÍCULO DE TRANSPORTE DE ESCOLARES EAD
        14 => 30, // ATUALIZAÇÃO PARA CONDUTORES DE VEÍCULO DE TRANSPORTE COLETIVO DE PASSAGEIROS EAD
        12 => 30, // ATUALIZAÇÃO PARA CONDUTORES DE VEÍCULO DE TRANSPORTE COLETIVO DE PASSAGEIROS EAD
        /*13 => 13, // CONDUTORES DE VEÍCULOS DE TRANSPORTE DE CARGA INDIVISÍVEL EAD
        12 => 12, // CONDUTORES DE VEÍCULOS DE EMERGÊNCIA EAD
        11 => 11, // CONDUTORES DE VEÍCULOS DE TRANSPORTE DE PRODUTOS PERIGOSOS EAD
        10 => 10, // CONDUTORES DE VEÍCULOS DE TRANSPORTE DE ESCOLARES EAD
        9 => 9,   // CONDUTORES DE VEÍCULO DE TRANSPORTE COLETIVO DE PASSAGEIROS EAD*/
    ],
    'AL' => [
        4 => 20, //RECICLAGEM DE CONDUTORES INFRATORES
        12 => 20, //RECICLAGEM DE CONDUTORES INFRATORES
    ],
    'CE' => [
        3 => 0, //RECICLAGEM DE CONDUTORES INFRATORES
    ],
    'SC' => [        //dev
        19 => 8,   //	MOTOTAXISTA SEMIPRESENCIAL
        18 => 9,   //	MOTOFRETISTA SEMIPRESENCIAL
        17 => 18,  //	ATUALIZAÇÃO PARA MOTOTAXISTA SEMIPRESENCIAL
        16 => 19,  //	ATUALIZAÇÃO PARA MOTOFRETISTA SEMIPRESENCIAL
        15 => 20,  //	RECICLAGEM PARA CONDUTORES INFRATORES EAD
        14 => 17,  //	ATUALIZAÇÃO PARA CONDUTORES DE VEÍCULO DE TRANSPORTE DE CARGA INDIVISÍVEL EAD
        12 => 14,  //	ATUALIZAÇÃO PARA CONDUTORES DE VEÍCULO DE EMERGÊNCIA EAD
        11 => 11,  //	ATUALIZAÇÃO PARA CONDUTORES DE VEÍCULO DE TRANSPORTE DE PRODUTOS PERIGOSOS EAD
        10 => 12,  //	ATUALIZAÇÃO PARA CONDUTORES VEÍCULO DE TRANSPORTE DE ESCOLARES EAD
        9 => 13,   //	ATUALIZAÇÃO PARA CONDUTORES DE VEÍCULO DE TRANSPORTE COLETIVO DE PASSAGEIROS EAD
        8 => 7,    //	CONDUTORES DE VEÍCULOS DE TRANSPORTE DE CARGA INDIVISÍVEL EAD
        6 => 4,    //	CONDUTORES DE VEÍCULOS DE EMERGÊNCIA EAD
        20 => 1,   //	CONDUTORES DE VEÍCULOS DE TRANSPORTE DE PRODUTOS PERIGOSOS EAD
        21 => 2,   //	CONDUTORES DE VEÍCULOS DE TRANSPORTE DE ESCOLARES EAD
        22 => 3,   //	CONDUTORES DE VEÍCULO DE TRANSPORTE COLETIVO DE PASSAGEIROS EAD
    ]
];

//Código das disciplinas no detran
$detran_codigo_materia = [
    'MA'  => [
        7 =>  'L',//Legislação de Trânsito
        8 =>  'D',//Direção Defensiva
        9 =>  'S',//Noções de Primeiros Socorros
        10 =>  'R'//Relacionamento Interpessoal
    ],
    'SE'  => [
        7 =>  'L',//Legislação de Trânsito
        8 =>  'D',//Direção Defensiva
        9 =>  'S',//Noções de Primeiros Socorros
        10 =>  'R'//Relacionamento Interpessoal
    ],
    'PE'  => [
        7 =>  'L',//Legislação de Trânsito
        8 =>  'D',//Direção Defensiva
        9 =>  'S',//Noções de Primeiros Socorros
        10 =>  'R'//Relacionamento Interpessoal
    ],
    'RS'  => [
        7 =>  'L',//Legislação de Trânsito
        8 =>  'D',//Direção Defensiva
        9 =>  'S',//Noções de Primeiros Socorros
        10 =>  'R'//Relacionamento Interpessoal
    ],
    'PR'  => [
        7 =>  'L',//Legislação de Trânsito
        8 =>  'D',//Direção Defensiva
        9 =>  'S',//Noções de Primeiros Socorros
        10 =>  'R'//Relacionamento Interpessoal
    ],
    'RJ'  => [
        7 =>  'L',//Legislação de Trânsito
        8 =>  'D',//Direção Defensiva
        9 =>  'S',//Noções de Primeiros Socorros
        10 =>  'R'//Relacionamento Interpessoal
    ],
    'ES'  => [
        7 =>  'L',//Legislação de Trânsito
        8 =>  'D',//Direção Defensiva
        9 =>  'S',//Noções de Primeiros Socorros
        10 =>  'R'//Relacionamento Interpessoal
    ],
    'MS'  => [
        7 =>  'L',//Legislação de Trânsito
        8 =>  'D',//Direção Defensiva
        9 =>  'S',//Noções de Primeiros Socorros
        10 =>  'R'//Relacionamento Interpessoal
    ],
    'MT'  => [
        7 =>  'L',//Legislação de Trânsito
        8 =>  'D',//Direção Defensiva
        9 =>  'S',//Noções de Primeiros Socorros
        10 =>  'R'//Relacionamento Interpessoal
    ],
    'AL'  => [
        7 =>  'L',//Legislação de Trânsito
        8 =>  'D',//Direção Defensiva
        9 =>  'S',//Noções de Primeiros Socorros
        10 =>  'R'//Relacionamento Interpessoal
    ]
];

//Horas aulas de cada disciplina para cada curso no detran
$detran_horas_aula = [
    'SE' => [
        'R' => [//RECICLAGEM DE CONDUTORES INFRATORES
            'L' =>  12,//Legislação de Trânsito
            'D' =>  8,//Direção Defensiva
            'S' =>  4,//Noções de Primeiros Socorros
            'R' =>  6//Relacionamento Interpessoal
        ],
        'A' => [//ATUALIZAÇÃO PARA RENOVAÇÃO DA CNH
            'D' =>  10,//Direção Defensiva
            'S' =>  5//Noções de Primeiros Socorros
        ]
    ],
    'PE' => [
    ],
    'RJ' => [
        7 =>  'L',//Legislação de Trânsito
        8 =>  'D',//Direção Defensiva
        9 =>  'S',//Noções de Primeiros Socorros
        10 =>  'R'//Relacionamento Interpessoal
    ],
];

$situacaoDetran['pt_br'] = array(
    'LI' =>  'Liberado',
    'NL' =>  'Não liberado',
    'AL' =>  'Aguardando liberação',
);

$detran_carga_horaria = [

    'SC' => [        // DEV
        19 => 30,    //	MOTOTAXISTA SEMIPRESENCIAL	SEMIPRESENCIAL
        18 => 30,    //	MOTOFRETISTA SEMIPRESENCIAL	SEMIPRESENCIAL
        17 => 10,    //	ATUALIZAÇÃO PARA MOTOTAXISTA SEMIPRESENCIAL	SEMIPRESENCIAL
        16 => 10,    //	ATUALIZAÇÃO PARA MOTOFRETISTA SEMIPRESENCIAL	SEMIPRESENCIAL
        15 => 30,    //	RECICLAGEM PARA CONDUTORES INFRATORES EAD	EAD
        14 => 16,    //	ATUALIZAÇÃO PARA CONDUTORES DE VEÍCULO DE TRANSPORTE DE CARGA INDIVISÍVEL EAD	EAD
        12 => 16,    //	ATUALIZAÇÃO PARA CONDUTORES DE VEÍCULO DE EMERGÊNCIA EAD	EAD
        11 => 16,    //	ATUALIZAÇÃO PARA CONDUTORES DE VEÍCULO DE TRANSPORTE DE PRODUTOS PERIGOSOS EAD	EAD
        10 => 16,    //	ATUALIZAÇÃO PARA CONDUTORES VEÍCULO DE TRANSPORTE DE ESCOLARES EAD	EAD
        9 => 16,    //	ATUALIZAÇÃO PARA CONDUTORES DE VEÍCULO DE TRANSPORTE COLETIVO DE PASSAGEIROS EAD	EAD
        8 => 50,    //	CONDUTORES DE VEÍCULOS DE TRANSPORTE DE CARGA INDIVISÍVEL EAD	EAD
        6 => 50,    //	CONDUTORES DE VEÍCULOS DE EMERGÊNCIA EAD	EAD
        20 => 20,    //	CONDUTORES DE VEÍCULOS DE TRANSPORTE DE PRODUTOS PERIGOSOS EAD	EAD
        21 => 50,    //	CONDUTORES DE VEÍCULOS DE TRANSPORTE DE ESCOLARES EAD	EAD

    ]
];
